import { gt, Range as range } from 'semver';

console.log(gt('1.2.3','2.1.2'));
const val=range("^1.2.2");

console.log("Hello");