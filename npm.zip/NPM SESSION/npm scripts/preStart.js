var colors= require('colors')
console.log(colors.green('server is pre starting'));
